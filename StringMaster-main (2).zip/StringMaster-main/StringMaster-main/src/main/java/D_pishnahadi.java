import java.util.regex.Pattern;

// reverse the given string then return the result
public class D_pishnahadi {
    public static String reverseWords(String str){
        Pattern  pattern = Pattern.compile("\\s");
        String[] temp = pattern.split(str);
        String result="";
        for(int i=0;i< temp.length;i++){
            if(i == temp.length-1)
                result = temp[i] + result;
            else
                result = " " + temp[i] + result;
        }
        return result;
    }
    // replace the old char with the new one
    public static String replace(String ss){
        return ss.replace('l','h');
    }
    // omit the spaces at the end and begging of the string
    public static String trim(String s){
        return s.trim();
    }
    // omit the given string from the original string
    public static String split(String str1 , String str2){
        String[] arrOfstr1 = str1.split(str2);
        StringBuilder result = new StringBuilder();
        for (String a : arrOfstr1)
            result.append(a);
        return String.valueOf(result);
    }
    // find the index of the specific given string
    public static String Index(String s , String ch){
        return String.valueOf(s.indexOf(ch));
    }
}
