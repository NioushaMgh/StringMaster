public class C_LoopAndString {
    /**
     * <p>Returns true if the string contains two consecutive character of
     * specified type.</p>
     *
     * <p>Example: "abbc" has two consecutive 'b'</p>
     *
     * @param s the given string
     * @param ch the given character
     * @return whether the string contains at least one consecutive pair of
     * the given character
     */
    public static boolean containsDoubleChar(String s, char ch) {

        int max=1;
        for(int i=1; i<s.length();i++){
            int count =1;
            while(i<s.length()&&s.charAt(i-1) == s.charAt(i)){
                count++;
                i++;
                max=Math.max(count,max);
            }
        }
        if(max==2)
            return true;
        return false;
    }

    /**
     * <p>Implement Caesar cipher encryption algorithm (tag: cryptography)
     * Google it for more information</p>
     * <p>Only encrypt alphabetical characters:
     * <b>"ab c" shift=3 => "de f"</b></p>
     * @param s text
     * @param offset shift amount
     * @return
     */
    public static String caesarEncrypt(String s, int offset) {
        StringBuffer result=new StringBuffer();
        for (int i=0;i<s.length();i++){
            char ch=s.charAt(i);
            if(ch<=64 || (ch>=91 && ch<=96))
                result.append(ch);
            else
            if (Character.isUpperCase(s.charAt(i))) {
                ch = (char) (((int) s.charAt(i) + offset - 65) % 26 + 65);
                while ((ch<'A')) ch+=26;
                result.append(ch);
            } else {
                ch = (char) (((int) s.charAt(i) + offset - 97) % 26 + 97);
                while ((ch<'a')) ch+=26;
                result.append(ch);
            }

        }
        return String.valueOf(result);
        }



    /**
     * <p>Implement Caesar cipher decryption algorithm (tag: cryptography)</p>
     * Google it for more information.</p>
     * <p>Ignore space: <b>"de f" shift=3 => "ab c"</b></p>
     * <p>You can use encryption method here.</p>
     *  @param s text
     * @param c shift amount
     * @return
     */
    public static String caesarDecrypt(String s, int c) {

        StringBuffer result=new StringBuffer();
        for (int i=0;i<s.length();i++){
            char ch=s.charAt(i);
            if(ch<=64 || (ch>=91 && ch<=96))
                result.append(ch);
            else
            if (Character.isUpperCase(s.charAt(i))) {
                ch = (char) (((int) s.charAt(i) - c - 65) % 26 + 65);
                while ((ch<'A')) ch+=26;
                result.append(ch);
            } else {
                ch = (char) (((int) s.charAt(i) - c - 97) % 26 + 97);
                while ((ch<'a')) ch+=26;
                result.append(ch);
            }

        }
        return String.valueOf(result);
    }

    /*
    If you have implemented all the previous parts completely and correctly
    feel free and add other methods as much as you want. Each extra method
    can add up to 5 points.

    Each method must come with its own unit-test.
     */
}
